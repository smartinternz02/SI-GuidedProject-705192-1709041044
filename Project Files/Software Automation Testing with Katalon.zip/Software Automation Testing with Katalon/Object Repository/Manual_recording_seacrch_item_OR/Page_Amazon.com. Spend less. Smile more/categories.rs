<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>categories</name>
   <tag></tag>
   <elementGuidId>ba04e79e-f8fc-476a-88f0-28968e48d259</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='nav-search-dropdown-card']/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.nav-search-scope.nav-sprite</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>39b646d3-5964-427b-8492-2cd1cfd9c9fe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-search-scope nav-sprite</value>
      <webElementGuid>9013faee-e227-4e18-87f0-27b8fdafb7ec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
      All
      
    
    Select the department you want to search in
    
        All Departments
        Alexa Skills
        Amazon Clinic
        Amazon Devices
        Amazon Pharmacy
        Amazon Warehouse
        Appliances
        Apps &amp; Games
        Arts, Crafts &amp; Sewing
        Audible Books &amp; Originals
        Automotive Parts &amp; Accessories
        Baby
        Beauty &amp; Personal Care
        Books
        CDs &amp; Vinyl
        Cell Phones &amp; Accessories
        Clothing, Shoes &amp; Jewelry
           Women
           Men
           Girls
           Boys
           Baby
        Collectibles &amp; Fine Art
        Computers
        Credit and Payment Cards
        Digital Music
        Electronics
        Garden &amp; Outdoor
        Gift Cards
        Grocery &amp; Gourmet Food
        Handmade
        Health, Household &amp; Baby Care
        Home &amp; Business Services
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Just for Prime
        Kindle Store
        Luggage &amp; Travel Gear
        Luxury Stores
        Magazine Subscriptions
        Movies &amp; TV
        Musical Instruments
        Office Products
        Pet Supplies
        Premium Beauty
        Prime Video
        Smart Home
        Software
        Sports &amp; Outdoors
        Subscribe &amp; Save
        Subscription Boxes
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under $10
        Video Games
    
  </value>
      <webElementGuid>404c665d-269a-42ee-b89a-43a66c141e0e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;nav-search-dropdown-card&quot;)/div[@class=&quot;nav-search-scope nav-sprite&quot;]</value>
      <webElementGuid>31720282-ddf2-4a35-b63e-f05e50b4e3ae</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-search-dropdown-card']/div</value>
      <webElementGuid>27e9f279-0690-4a69-ac3b-e3bc9d7f09b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div/div/div</value>
      <webElementGuid>2f811ddb-a79e-4b94-a683-a81d6ad74edb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
    
      All
      
    
    Select the department you want to search in
    
        All Departments
        Alexa Skills
        Amazon Clinic
        Amazon Devices
        Amazon Pharmacy
        Amazon Warehouse
        Appliances
        Apps &amp; Games
        Arts, Crafts &amp; Sewing
        Audible Books &amp; Originals
        Automotive Parts &amp; Accessories
        Baby
        Beauty &amp; Personal Care
        Books
        CDs &amp; Vinyl
        Cell Phones &amp; Accessories
        Clothing, Shoes &amp; Jewelry
           Women
           Men
           Girls
           Boys
           Baby
        Collectibles &amp; Fine Art
        Computers
        Credit and Payment Cards
        Digital Music
        Electronics
        Garden &amp; Outdoor
        Gift Cards
        Grocery &amp; Gourmet Food
        Handmade
        Health, Household &amp; Baby Care
        Home &amp; Business Services
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Just for Prime
        Kindle Store
        Luggage &amp; Travel Gear
        Luxury Stores
        Magazine Subscriptions
        Movies &amp; TV
        Musical Instruments
        Office Products
        Pet Supplies
        Premium Beauty
        Prime Video
        Smart Home
        Software
        Sports &amp; Outdoors
        Subscribe &amp; Save
        Subscription Boxes
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under $10
        Video Games
    
  ' or . = '
    
      All
      
    
    Select the department you want to search in
    
        All Departments
        Alexa Skills
        Amazon Clinic
        Amazon Devices
        Amazon Pharmacy
        Amazon Warehouse
        Appliances
        Apps &amp; Games
        Arts, Crafts &amp; Sewing
        Audible Books &amp; Originals
        Automotive Parts &amp; Accessories
        Baby
        Beauty &amp; Personal Care
        Books
        CDs &amp; Vinyl
        Cell Phones &amp; Accessories
        Clothing, Shoes &amp; Jewelry
           Women
           Men
           Girls
           Boys
           Baby
        Collectibles &amp; Fine Art
        Computers
        Credit and Payment Cards
        Digital Music
        Electronics
        Garden &amp; Outdoor
        Gift Cards
        Grocery &amp; Gourmet Food
        Handmade
        Health, Household &amp; Baby Care
        Home &amp; Business Services
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Just for Prime
        Kindle Store
        Luggage &amp; Travel Gear
        Luxury Stores
        Magazine Subscriptions
        Movies &amp; TV
        Musical Instruments
        Office Products
        Pet Supplies
        Premium Beauty
        Prime Video
        Smart Home
        Software
        Sports &amp; Outdoors
        Subscribe &amp; Save
        Subscription Boxes
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under $10
        Video Games
    
  ')]</value>
      <webElementGuid>223366b9-1df6-4154-8aab-5517b412ece0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
