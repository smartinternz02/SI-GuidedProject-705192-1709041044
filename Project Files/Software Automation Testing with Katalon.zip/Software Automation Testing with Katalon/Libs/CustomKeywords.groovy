
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String

import com.kms.katalon.core.testobject.TestObject



def static "com.qa.test.customkeywords.hello"() {
    (new com.qa.test.customkeywords()).hello()
}


def static "com.qa.test.customkeywords.myname"(
    	String name	) {
    (new com.qa.test.customkeywords()).myname(
        	name)
}


def static "com.qa.test.customkeywords.CheckDropDownListElementExists"(
    	TestObject object	
     , 	String option	) {
    (new com.qa.test.customkeywords()).CheckDropDownListElementExists(
        	object
         , 	option)
}
